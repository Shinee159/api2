<div align="center">

<img src="public/og-image.jpg" alt="Nontonime" width="100%" />

# Nontonime

Website streaming anime subtitle Indonesia — tanpa iklan mengganggu, tanpa akun, dan performa ultra cepat.

[![Demo](https://img.shields.io/badge/demo-nontonime.vercel.app-6366f1?style=for-the-badge&logo=vercel&logoColor=white)](https://nontonime.vercel.app/)
[![Deploy](https://img.shields.io/github/deployments/Nimzz-pemboy/nontonime/production?style=for-the-badge&label=vercel&logo=vercel)](https://nontonime.vercel.app/)

[![Last Commit](https://img.shields.io/github/last-commit/Nimzz-pemboy/nontonime?style=flat-square)](https://github.com/Nimzz-pemboy/nontonime/commits/main)
[![Repo Size](https://img.shields.io/github/repo-size/Nimzz-pemboy/nontonime?style=flat-square)](https://github.com/Nimzz-pemboy/nontonime)
[![Top Language](https://img.shields.io/github/languages/top/Nimzz-pemboy/nontonime?style=flat-square)](https://github.com/Nimzz-pemboy/nontonime)
[![Stars](https://img.shields.io/github/stars/Nimzz-pemboy/nontonime?style=flat-square)](https://github.com/Nimzz-pemboy/nontonime/stargazers)
[![Forks](https://img.shields.io/github/forks/Nimzz-pemboy/nontonime?style=flat-square)](https://github.com/Nimzz-pemboy/nontonime/network/members)
[![Issues](https://img.shields.io/github/issues/Nimzz-pemboy/nontonime?style=flat-square)](https://github.com/Nimzz-pemboy/nontonime/issues)
[![License](https://img.shields.io/github/license/Nimzz-pemboy/nontonime?style=flat-square)](./LICENSE)

</div>

---

## Tentang Proyek

**Nontonime** adalah platform web modern untuk streaming anime subtitle Indonesia dengan fokus pada **User Experience (UX) kelas atas**, performa kilat, dan kemudahan akses tanpa registrasi akun. Seluruh katalog anime, jadwal rilis harian, episode, serta multi-server streaming diambil server-side dari lapisan API proxy internal berkecepatan tinggi.

Semua preferensi personal seperti **Riwayat Tontonan**, **Watchlist**, dan **Langganan Notifikasi Rilis** tersimpan aman di penyimpanan lokal (Local Storage & IndexedDB) pengguna.

---

## Arsitektur & Desain UI/UX

Redesign Nontonime menggunakan antarmuka streaming **compact, mobile-first, dan dark-first** dengan aksen electric purple. Perubahan visual tidak mengubah kontrak route, server functions, query keys, tipe respons API, playback, history, watchlist, download, subscription, maupun push notification.

- **Design system semantik**: warna utama purple melalui token CSS, surface gelap berlapis, focus ring konsisten, dan target sentuh minimal 44×44 px.
- **Compact content system**: kartu poster rasio 2:3, grid responsif 2–6 kolom, fallback poster stabil, shelf horizontal pada mobile, dan trending cards yang lebih padat.
- **Resilient watch experience**: pemilihan kualitas/server dipisahkan dari player; ketika resolusi server baru gagal, URL playable sebelumnya tetap dipertahankan dan pengguna dapat memilih server lain.
- **Personal library yang aman**: history dan watchlist tetap berbasis local storage tetapi read/write gagal secara aman ketika storage tidak tersedia atau JSON rusak.
- **Progressive loading**: gacha, quick preview, spotlight search, filter panel, dan watch enhancements dimuat saat dibutuhkan agar UI awal tetap kecil.
- **Accessibility**: navigasi keyboard, accessible labels, status tidak hanya dibedakan dengan warna, dukungan `prefers-reduced-motion`, serta Lucide sebagai satu-satunya icon system pada UI redesign.
- **SSR tetap dipertahankan** untuk konten route utama dan metadata. Navigasi inti, kartu konten, watch actions, dan video playback tidak bergantung pada deferred chunks.

---

## Sumber Data & Server Functions

Data anime diperoleh melalui client server-side di `src/lib/animein.server.ts` dengan arsitektur:
1. **Server-Only Security**: Endpoint dan rahasia proxy dieksekusi murni di backend via TanStack Start `createServerFn` (`src/lib/anime.functions.ts`). Kredensial tidak pernah terekspos ke browser.
2. **Instant Multi-Server Resolution**: Pemanggilan stream episode langsung menyediakan seluruh opsi server (OtakuWatch, OdStream, VidHide, Mega, dll.) dan resolusi (360p, 480p, 720p HD) dalam satu payload, memungkinkan pergantian server instan tanpa request ulang.
3. **Context-Aware Navigation**: Parameter konteks anime (`?a=<animeId>`) disematkan otomatis pada tautan tontonan untuk sinkronisasi daftar episode, histori, dan metadata.

---

## Fitur Unggulan

| Fitur | Deskripsi |
| :--- | :--- |
| **Trending Anime Compact Slider** | Rak trending dengan kartu ranking yang padat, responsif, dan tidak bersaing dengan hero utama. |
| **Watchlist & Profil** | Simpan dan kelola anime secara lokal, termasuk import/export dan state kosong yang aman. |
| **Compact Mobile Navigation** | Navigasi bawah dengan Beranda, Jelajahi, Jadwal, Watchlist, dan Riwayat serta target sentuh minimal 44 px. |
| **Search & Filter On-Demand** | Search/filter tetap tersedia tetapi secondary overlays dimuat secara lazy saat dibuka. |
| **Compact Hero** | Hero fokus pada satu slide aktif dengan dua aksi utama dan animasi yang menghormati reduced-motion. |
| **Rak Anime Berbasis Status** | Rak terpisah untuk *Tayang Hari Ini*, *Sedang Tayang (Ongoing)*, *Anime Tamat (Completed)*, dan *Rekomendasi Pilihan*. |
| **Jadwal Rilis Mingguan** | Kalender rilis anime per hari (Senin–Minggu) dengan penanda otomatis hari ini. |
| **Eksplorasi Genre** | Direktori genre lengkap dengan navigasi berbasis teks yang bersih tanpa ikon berat. |
| **Player Video Multi-Kualitas** | Pemutar video responsif dengan dukungan server embed dan streaming langsung (`.mp4` / `.m3u8`). |
| **Riwayat & Lanjutkan Nonton** | Pelacakan otomatis episode terakhir yang ditonton, tersimpan lokal di perangkat. |
| **Notifikasi Web Push Native** | Langganan notifikasi episode baru per anime menggunakan Web Push API bawaan browser. |
| **PWA & Akses Offline** | Installable ke homescreen HP & tablet dengan dukungan offline state view yang elegan. |

---

## Tumpukan Teknologi

- **Framework**: [TanStack Start](https://tanstack.com/start) (React 19, Full-stack SSR & Server Functions)
- **Routing**: [TanStack Router](https://tanstack.com/router) (File-based, 100% type-safe routing)
- **State & Data Fetching**: [TanStack Query v5](https://tanstack.com/query)
- **Physics Animations**: [Motion](https://motion.dev/) (Spring animations, Layout transitions)
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/) dengan OKLCH color token & theme switching
- **Icon Set**: [Lucide React](https://lucide.dev/)
- **Carousel**: [Embla Carousel React](https://www.embla-carousel.com/)
- **Video Engine**: [Video.js](https://videojs.com/)
- **Notification Toast**: [Sonner](https://sonner.emilkowal.ski/)
- **Push Notification**: Native Web Push API (Service Worker + VAPID)
- **Runtime & Deployment**: [Nitro Engine](https://nitro.build/) (Vercel / Node.js)

---

## Panduan Instalasi & Pengembangan Lokal

### Prasyarat
- **Node.js**: versi 20.x atau lebih baru
- **npm** atau **pnpm**

### Langkah Instalasi
```bash
# 1. Kloning repositori
git clone https://github.com/Nimzz-pemboy/nontonime.git
cd nontonime

# 2. Pasang dependensi
npm install

# 3. Siapkan environment variable
cp .env.example .env

# 4. Jalankan dev server
npm run dev
```

Aplikasi dapat diakses melalui peramban di `http://localhost:3000` (atau port yang ditentukan lingkungan).

---

## Skrip yang Tersedia

| Perintah | Deskripsi |
| :--- | :--- |
| `npm run dev` | Menjalankan server pengembangan dengan hot reload |
| `npm run build` | Menjalankan build produksi (client bundles + server bundles) |
| `npm run preview` | Menjalankan preview lokal dari hasil build |
| `npm run lint` | Memeriksa kepatuhan kode dan sintaks dengan ESLint |
| `npm run format` | Memformat kode menggunakan Prettier |
| `npm run test:run` | Menjalankan seluruh test Vitest satu kali |
| `npx tsc --noEmit` | Memeriksa tipe TypeScript tanpa menghasilkan file |

---

## Struktur Direktori

```
src/
├── components/
│   ├── anime/       # Komponen anime (AnimeCard, HeroSlider, Shelf, Player, BottomNav, dll.)
│   └── ui/          # Komponen primitif antarmuka
├── lib/
│   ├── animein.server.ts   # Client server-side scraping & rate limiting
│   ├── anime.functions.ts  # Server Functions per endpoint
│   ├── anime-types.ts      # TypeScript definitions untuk anime, episode, dan jadwal
│   ├── queries.ts          # TanStack Query query options
│   ├── history.ts          # State storage riwayat tontonan
│   ├── watchlist.ts        # State storage watchlist
│   ├── subscriptions.ts    # State storage langganan notifikasi
│   └── push.ts             # Integrasi Web Push & VAPID
├── routes/          # File-based routing (Beranda, Detail, Nonton, Genre, Jadwal, Profil)
├── styles.css       # Token Tailwind CSS, utilitas OKLCH, dan styling global
└── start.ts         # Middleware TanStack Start
```

---

<div align="center">
Dikelola dan dikembangkan dengan bangga oleh <strong>Nimzz</strong>.
</div>
