import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const source = (path: string) => readFileSync(new URL(path, import.meta.url), "utf8");

describe("redesign accessibility contract", () => {
  it("removes Font Awesome markup and stylesheet references from src", () => {
    const files = [
      "../routes/__root.tsx",
      "../routes/watchlist.tsx",
      "../routes/jadwal.tsx",
      "../components/anime/AnimeListRow.tsx",
      "../components/anime/EpisodeDownloadButton.tsx",
      "../components/anime/EpisodeList.tsx",
      "../components/anime/Pagination.tsx",
      "../components/anime/ShareButton.tsx",
    ];
    for (const file of files) expect(source(file)).not.toMatch(/fa-(?:solid|regular|brands)|font-awesome/i);
  });

  it("gives the custom spotlight dialog an accessible name", () => {
    const modal = source("../components/anime/SpotlightSearchModal.tsx");
    expect(modal).toContain('aria-labelledby="spotlight-search-title"');
    expect(modal).toContain('id="spotlight-search-title"');
  });

  it("mounts secondary header overlays only while open", () => {
    const header = source("../components/anime/SiteHeader.tsx");
    expect(header).toContain("lazy(() => import");
    expect(header).toContain("showSpotlight ?");
    expect(header).toContain("showGachaModal ?");
    expect(header).toContain("showFilterPanel ?");
  });
});
