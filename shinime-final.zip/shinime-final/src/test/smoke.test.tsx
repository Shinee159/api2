import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

describe("test harness", () => {
  it("renders React content in jsdom", () => {
    render(<button type="button">Nonton sekarang</button>);
    expect(screen.getByRole("button", { name: "Nonton sekarang" })).toBeVisible();
  });
});
