import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const css = readFileSync(new URL("../styles.css", import.meta.url), "utf8");

describe("visual CSS contract", () => {
  it("defines the approved primary palette and reduced-motion override", () => {
    expect(css).toContain("--primary:");
    expect(css).toContain("#7C4DFF");
    expect(css).toContain("@media (prefers-reduced-motion: reduce)");
    expect(css).toContain("animation-duration: 0.01ms");
  });
});
