import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AnimeDetailHero } from "@/components/anime/AnimeDetailHero";
import { EpisodeBrowser } from "@/components/anime/EpisodeBrowser";
import { AnimeGrid } from "@/components/anime/AnimeGrid";
import { ErrorState, LoadingState } from "@/components/anime/StateViews";
import { animeDetailQuery } from "@/lib/queries";
export const Route=createFileRoute("/anime/$animeId")({component:Page});
function Page(){const {animeId}=Route.useParams();const q=useQuery(animeDetailQuery(animeId));if(q.isPending)return <LoadingState label="Memuat informasi anime..."/>;if(q.error||!q.data)return <div className="page-shell py-10"><ErrorState error={q.error||new Error("Anime tidak ditemukan")} onRetry={()=>q.refetch()}/></div>;const a=q.data;return <main className="page-shell min-w-0 space-y-6 py-6"><AnimeDetailHero anime={a}/>{a.synopsis?<section className="rounded-2xl border border-border bg-card p-5"><h2 className="text-lg font-bold">Sinopsis</h2><p className="mt-2 whitespace-pre-line text-sm leading-7 text-muted-foreground">{a.synopsis}</p></section>:null}<EpisodeBrowser episodes={a.episodes} animeId={a.id}/>{a.batch?<section className="rounded-2xl border border-border bg-card p-5"><h2 className="font-bold">Unduh Batch</h2><Link to="/download/$batchId" params={{batchId:a.batch.batchId}} className="tap-target mt-3 inline-flex items-center rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground">Buka unduhan batch</Link></section>:null}{a.recommended?.length?<section><h2 className="mb-4 text-lg font-bold">Rekomendasi</h2><AnimeGrid items={a.recommended}/></section>:null}</main>}
