import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CatalogLayout } from "@/components/anime/CatalogLayout";
import { Pagination } from "@/components/anime/Pagination";
import { genreAnimeQuery } from "@/lib/queries";
export const Route=createFileRoute("/genre/$genreId")({validateSearch:(s:Record<string,unknown>)=>({page:Number(s.page??1)||1,name:s.name?String(s.name):undefined}),component:Page});
function Page(){const {genreId}=Route.useParams();const {page,name}=Route.useSearch();const navigate=useNavigate();const q=useQuery(genreAnimeQuery(genreId,page));return <CatalogLayout title={`Genre: ${name??genreId}`} description="Jelajahi anime berdasarkan genre pilihan." items={q.data?.items??[]} isPending={q.isPending} error={q.error} onRetry={()=>q.refetch()} pagination={q.data?<Pagination page={page} hasNext={q.data.hasNext} onChange={n=>navigate({to:"/genre/$genreId",params:{genreId},search:{page:n,name}})}/>:null}/>}
