import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search } from "lucide-react";
import { CatalogLayout } from "@/components/anime/CatalogLayout";
import { Pagination } from "@/components/anime/Pagination";
import { searchQuery } from "@/lib/queries";
export const Route=createFileRoute("/cari")({validateSearch:(s:Record<string,unknown>)=>({q:String(s.q??""),page:Number(s.page??1)||1}),component:Page});
function Page(){const {q,page}=Route.useSearch(); const navigate=useNavigate(); const [term,setTerm]=useState(q); const query=useQuery(searchQuery(q,page)); const toolbar=<form className="flex min-w-0 flex-1 gap-2" onSubmit={e=>{e.preventDefault();navigate({to:"/cari",search:{q:term.trim(),page:1}})}}><label className="relative min-w-0 flex-1"><Search aria-hidden className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"/><input aria-label="Cari anime" value={term} onChange={e=>setTerm(e.target.value)} placeholder="Ketik judul anime" className="tap-target w-full min-w-0 rounded-xl border border-border bg-card pl-9 pr-3 text-sm focus-ring"/></label><button className="tap-target rounded-xl bg-primary px-4 text-sm font-bold text-primary-foreground">Cari</button></form>; return <CatalogLayout title={q?`Hasil: ${q}`:"Cari Anime"} description="Cari judul anime dari katalog Shinime." items={q?(query.data?.items??[]):[]} isPending={Boolean(q)&&query.isPending} error={q?query.error:null} onRetry={()=>query.refetch()} toolbar={toolbar} pagination={q&&query.data?<Pagination page={page} hasNext={query.data.hasNext} onChange={n=>navigate({to:"/cari",search:{q,page:n}})}/>:null}/>}
