import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { lazy, Suspense, useEffect, useState } from "react";
import { HeroSlider } from "@/components/anime/HeroSlider";
import { TrendingSlider } from "@/components/anime/TrendingSlider";
import { ContinueWatching } from "@/components/anime/ContinueWatching";
import { Shelf } from "@/components/anime/Shelf";
import { ErrorState } from "@/components/anime/StateViews";
import { FloatingTools } from "@/components/anime/FloatingTools";
import { HomeSidebar } from "@/components/anime/HomeSidebar";
import { homeQuery, currentDayName } from "@/lib/queries";
import { readHistory, type HistoryItem } from "@/lib/history";
import { CalendarDays, CheckCircle2, Flame, Sparkles } from "lucide-react";

const AnimeGachaModal = lazy(() => import("@/components/anime/AnimeGachaModal").then(m => ({ default: m.AnimeGachaModal })));
const SearchFilterPanel = lazy(() => import("@/components/anime/SearchFilterPanel").then(m => ({ default: m.SearchFilterPanel })));

export const Route = createFileRoute("/")({
  loader: async ({ context }) => { try { await context.queryClient.ensureQueryData(homeQuery()); } catch {} },
  head: () => ({ meta: [{ title: "Shinime — Streaming Anime Subtitle Indonesia Terbaru" }, { name:"description", content:"Nonton anime subtitle Indonesia terlengkap dan terupdate gratis." }] }),
  component: HomePage,
});
const POPULAR_GENRES=["Action","Isekai","Fantasy","Romance","Comedy","Shounen","Adventure","Slice of Life","Supernatural","Sci-Fi","Mystery","Drama"].map(name=>({id:name.toLowerCase().replaceAll(" ","-"),name}));
function HomePage(){
 const {data,isPending,error,refetch}=useQuery(homeQuery()); const [history,setHistory]=useState<HistoryItem[]>([]); const [gachaOpen,setGachaOpen]=useState(false); const [filterOpen,setFilterOpen]=useState(false); const today=currentDayName();
 useEffect(()=>{const sync=()=>setHistory(readHistory().slice(0,4));sync();window.addEventListener("history-updated",sync);return()=>window.removeEventListener("history-updated",sync)},[]);
 return <div className="page-shell min-w-0 py-5 sm:py-7">
  {isPending?<div className="h-[25rem] w-full rounded-2xl bg-muted/60" aria-label="Memuat beranda"/>:null}
  {error?<ErrorState error={error} onRetry={()=>refetch()}/>:null}
  {data?.slider.length?<HeroSlider items={data.slider.slice(0,7)}/>:null}
  <div className="mt-6 min-w-0">
   <div className="section-stack min-w-0">
    <ContinueWatching items={history}/>
    {data&&(data.hot.length||data.slider.length)?<TrendingSlider items={(data.hot.length?data.hot:data.slider).slice(0,10)}/>:null}
    <Shelf title={`Baru Hari ${today}`} icon={CalendarDays} items={data?.today??[]} isLoading={isPending} viewAllTo="/jadwal"/>
    <Shelf title="Sedang Tayang (Ongoing)" icon={Flame} items={data?.hot??[]} isLoading={isPending} viewAllTo="/ongoing" viewAllSearch={{page:1}}/>
    <Shelf title="Anime Tamat (Completed)" icon={CheckCircle2} items={data?.popular??[]} isLoading={isPending} viewAllTo="/tamat" viewAllSearch={{page:1}}/>
    <Shelf title="Rekomendasi Pilihan" icon={Sparkles} items={data?.new??[]} isLoading={isPending}/>
    <section className="space-y-3"><div className="flex items-end justify-between gap-3"><h2 className="text-lg font-bold">Jelajahi Genre</h2><Link to="/genre" className="text-xs font-semibold text-primary">Lihat semua →</Link></div><div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">{POPULAR_GENRES.slice(0,8).map(g=><Link key={g.id} to="/genre/$genreId" params={{genreId:g.id}} search={{page:1,name:g.name}} className="tap-target inline-flex items-center rounded-xl border border-border bg-card px-4 text-xs font-semibold transition hover:border-primary/60 hover:bg-primary/5">{g.name}</Link>)}</div></section>
    <HomeSidebar items={data?.today?.length?data.today:(data?.hot??[])}/>
   </div>
  </div>
  <FloatingTools onOpenFilter={()=>setFilterOpen(true)}/>
  {gachaOpen?<Suspense fallback={null}><AnimeGachaModal open onOpenChange={setGachaOpen}/></Suspense>:null}
  {filterOpen?<Suspense fallback={null}><SearchFilterPanel open onOpenChange={setFilterOpen}/></Suspense>:null}
 </div>
}
