import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CatalogLayout } from "@/components/anime/CatalogLayout";
import { Pagination } from "@/components/anime/Pagination";
import { completedQuery } from "@/lib/queries";
export const Route=createFileRoute("/tamat")({ validateSearch:(s:Record<string,unknown>)=>({page:Number(s.page??1)||1}), component:Page });
function Page(){ const {page}=Route.useSearch(); const navigate=useNavigate(); const q=useQuery(completedQuery(page)); return <CatalogLayout title="Anime Tamat" description="Koleksi anime yang sudah selesai tayang dan siap dimaraton." items={q.data?.items??[]} isPending={q.isPending} error={q.error} onRetry={()=>q.refetch()} pagination={q.data?<Pagination page={page} hasNext={q.data.hasNext} onChange={next=>navigate({to:"/tamat",search:{page:next}})}/>:null}/>; }
