import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { lazy, Suspense, useEffect, useMemo, useState } from "react";
import { VideoPlayer } from "@/components/anime/VideoPlayer";
import { ShareButton } from "@/components/anime/ShareButton";
import { WatchServerControls } from "@/components/anime/WatchServerControls";
import { WatchEpisodeSidebar } from "@/components/anime/WatchEpisodeSidebar";
import { ErrorState, LoadingState } from "@/components/anime/StateViews";
import { animeDetailQuery, streamQuery } from "@/lib/queries";
import { fetchResolveServer } from "@/lib/anime.functions";
import { saveHistory } from "@/lib/history";
import { cn } from "@/lib/utils";
import { resolveStreamSelection } from "@/lib/stream-selection";
import { ChevronRight, Download, ExternalLink, Info, SkipBack, SkipForward } from "lucide-react";

const WatchEnhancements = lazy(() => import("@/components/anime/WatchEnhancements").then(m => ({ default: m.WatchEnhancements })));

export const Route = createFileRoute("/watch/$episodeId")({
  validateSearch: (search: Record<string, unknown>) => ({
    a: search["a"] ? String(search["a"]) : undefined,
  }),
  head: ({ params }) => {
    const name = params.episodeId.replace(/-/g, " ");
    return {
      meta: [
        { title: `Nonton ${name} — Shinime` },
        {
          name: "description",
          content: "Streaming anime subtitle Indonesia dengan pilihan resolusi dan server cepat.",
        },
        { property: "og:title", content: `Nonton ${name} — Shinime` },
        { property: "og:description", content: "Streaming anime subtitle Indonesia." },
      ],
    };
  },
  component: WatchPage,
});

function WatchPage() {
  const { episodeId } = Route.useParams();
  const { a: searchAnimeId } = Route.useSearch();
  const [isTheater, setIsTheater] = useState(false);
  const [isAmbient, setIsAmbient] = useState(false);
  const [isSleepTriggered, setIsSleepTriggered] = useState(false);

  const stream = useQuery(streamQuery(episodeId));

  const resolvedAnimeId = searchAnimeId || stream.data?.animeId || "";
  const anime = useQuery({
    ...animeDetailQuery(resolvedAnimeId),
    enabled: Boolean(resolvedAnimeId),
  });

  const [currentStreamUrl, setCurrentStreamUrl] = useState<string | null>(null);
  const [selectedQuality, setSelectedQuality] = useState<string | null>(null);
  const [selectedServerId, setSelectedServerId] = useState<string | null>(null);
  const [isResolving, setIsResolving] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const [showEnhancements, setShowEnhancements] = useState(false);

  // Sync stream default URL on episode load
  useEffect(() => {
    if (stream.data?.defaultStreamingUrl) {
      setCurrentStreamUrl(stream.data.defaultStreamingUrl);
    }
    setSelectedServerId(null);
    setSelectedQuality(null);
  }, [episodeId, stream.data?.defaultStreamingUrl]);

  // Server qualities
  const qualityGroups = useMemo(() => {
    return stream.data?.servers?.qualities ?? [];
  }, [stream.data?.servers?.qualities]);

  // Set default quality
  useEffect(() => {
    if (!selectedQuality && qualityGroups.length > 0) {
      // Prefer 720p or highest available
      const preferred =
        qualityGroups.find((q) => q.quality.includes("720")) ??
        qualityGroups.find((q) => q.quality.includes("480")) ??
        qualityGroups[0];
      if (preferred) {
        setSelectedQuality(preferred.quality);
      }
    }
  }, [qualityGroups, selectedQuality]);

  const activeGroup = useMemo(() => {
    return qualityGroups.find((q) => q.quality === selectedQuality) ?? qualityGroups[0];
  }, [qualityGroups, selectedQuality]);

  // Handle server switch without discarding the last playable URL on failure
  const handleServerSelect = async (serverId: string) => {
    if (serverId === selectedServerId || isResolving) return;
    setIsResolving(true);
    setServerError(null);
    const result = await resolveStreamSelection({
      serverId,
      previousUrl: currentStreamUrl,
      resolve: (id) => fetchResolveServer({ data: { serverId: id } }),
    });
    setCurrentStreamUrl(result.url);
    setServerError(result.error);
    if (result.selectedServerId) setSelectedServerId(result.selectedServerId);
    setIsResolving(false);
  };

  // Episodes list from either anime detail query or stream info
  const episodeList = useMemo(() => {
    if (anime.data?.episodes && anime.data.episodes.length > 0) {
      return anime.data.episodes;
    }
    if (stream.data?.info?.episodeList && stream.data.info.episodeList.length > 0) {
      return stream.data.info.episodeList.map((ep) => ({
        id: ep.episodeId,
        number: ep.eps,
        title: ep.title,
      }));
    }
    return [];
  }, [anime.data?.episodes, stream.data?.info?.episodeList]);

  const sortedEpisodes = useMemo(() => {
    return [...episodeList].sort((a, b) => a.number - b.number);
  }, [episodeList]);

  const activeIndex = sortedEpisodes.findIndex((ep) => ep.id === episodeId);
  const prevEp = activeIndex > 0 ? sortedEpisodes[activeIndex - 1] : undefined;
  const nextEp =
    activeIndex >= 0 && activeIndex < sortedEpisodes.length - 1
      ? sortedEpisodes[activeIndex + 1]
      : undefined;

  const prevEpisodeId = prevEp?.id ?? stream.data?.prevEpisodeId ?? null;
  const nextEpisodeId = nextEp?.id ?? stream.data?.nextEpisodeId ?? null;

  // Save to history
  useEffect(() => {
    if (!stream.data) return;
    const animeTitle = anime.data?.title || stream.data.title;
    const poster = anime.data?.poster || "";
    saveHistory({
      episodeId,
      animeId: resolvedAnimeId,
      animeTitle,
      episodeTitle: stream.data.title,
      poster,
      watchedAt: Date.now(),
    });
  }, [stream.data, anime.data, resolvedAnimeId, episodeId]);

  if (stream.isPending) return <LoadingState label="Menyiapkan episode & server streaming..." />;
  if (stream.error) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12">
        <ErrorState error={stream.error} onRetry={() => stream.refetch()} />
      </div>
    );
  }

  const episodeData = stream.data;
  const animeTitle = anime.data?.title || episodeData.title;

  return (
    <div
      className={cn(
        "mx-auto px-4 py-6 transition-all duration-300",
        isTheater ? "max-w-full" : "max-w-7xl",
      )}
    >
      {/* Top Breadcrumb & Info */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-2 overflow-hidden">
          <Link to="/" className="hover:text-primary transition-colors shrink-0">
            Beranda
          </Link>
          <ChevronRight className="size-3 shrink-0" />
          {resolvedAnimeId ? (
            <>
              <Link
                to="/anime/$animeId"
                params={{ animeId: resolvedAnimeId }}
                className="hover:text-primary transition-colors truncate max-w-[200px] sm:max-w-xs font-medium"
              >
                {animeTitle}
              </Link>
              <ChevronRight className="size-3 shrink-0" />
            </>
          ) : null}
          <span className="text-foreground font-semibold truncate">{episodeData.title}</span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <ShareButton title={episodeData.title} />
          {resolvedAnimeId ? (
            <Link
              to="/anime/$animeId"
              params={{ animeId: resolvedAnimeId }}
              className="inline-flex items-center gap-1.5 rounded-full border border-border/80 bg-card px-3 py-1 font-medium text-foreground hover:bg-accent"
            >
              <Info className="size-4 text-primary" />
              Detail Anime
            </Link>
          ) : null}
        </div>
      </div>

      {/* Main Layout: Video Player + Episode Selector */}
      <div className="grid gap-6 lg:grid-cols-12">
        {/* Left / Center Video Player Column */}
        <div
          className={cn("space-y-4", isTheater ? "lg:col-span-12" : "lg:col-span-8 xl:col-span-9")}
        >
          {/* Video Container with Ambient Light Effect */}
          <div className="relative group">
            {isAmbient ? (
              <div
                aria-hidden="true"
                className="absolute -inset-3 sm:-inset-6 -z-10 rounded-3xl bg-primary/25 blur-3xl opacity-70 transition-opacity duration-700 pointer-events-none"
              />
            ) : null}

            <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-black border border-border/80">
              {isSleepTriggered ? (
                <div className="flex aspect-video w-full flex-col items-center justify-center bg-black/95 p-6 text-center text-white space-y-3">
                  <span className="text-4xl">🌙</span>
                  <h3 className="text-base font-bold">Waktu Tidur Telah Tiba</h3>
                  <p className="text-xs text-muted-foreground max-w-xs">
                    Pemutaran anime dihentikan otomatis oleh Sleep Timer untuk menghemat daya dan
                    kuota.
                  </p>
                  <button
                    type="button"
                    onClick={() => setIsSleepTriggered(false)}
                    className="rounded-xl bg-primary px-4 py-2 text-xs font-bold text-primary-foreground hover:bg-primary/90 transition-colors"
                  >
                    Lanjutkan Menonton
                  </button>
                </div>
              ) : (
                <VideoPlayer
                  src={currentStreamUrl}
                  isTheater={isTheater}
                  onToggleTheater={() => setIsTheater((prev) => !prev)}
                />
              )}
            </div>
          </div>

          {/* Player Controls: Server selection + Navigation */}
          <div className="rounded-2xl border border-border/80 bg-card p-4 space-y-4 shadow-sm">
            {/* Episode Title & Prev/Next Quick Navigation + Enhancements */}
            <div className="flex flex-col gap-3 border-b border-border/60 pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <h1 className="font-display text-base sm:text-lg font-bold text-foreground">
                    {episodeData.title}
                  </h1>
                  {episodeData.releaseTime ? (
                    <p className="text-xs text-muted-foreground">{episodeData.releaseTime}</p>
                  ) : null}
                </div>

                {/* Prev / Next buttons */}
                <div className="flex items-center gap-2">
                  {prevEpisodeId ? (
                    <Link
                      to="/watch/$episodeId"
                      params={{ episodeId: prevEpisodeId }}
                      search={{ a: resolvedAnimeId }}
                      className="press-soft inline-flex items-center gap-1.5 rounded-xl border border-border/80 bg-background px-3 py-1.5 text-xs font-semibold text-foreground hover:bg-accent"
                    >
                      <SkipBack className="size-4" />
                      Eps Sebelumnya
                    </Link>
                  ) : (
                    <button
                      disabled
                      className="inline-flex items-center gap-1.5 rounded-xl border border-border/40 bg-muted/40 px-3 py-1.5 text-xs font-semibold text-muted-foreground/50 cursor-not-allowed"
                    >
                      <SkipBack className="size-4" />
                      Eps Sebelumnya
                    </button>
                  )}

                  {nextEpisodeId ? (
                    <Link
                      to="/watch/$episodeId"
                      params={{ episodeId: nextEpisodeId }}
                      search={{ a: resolvedAnimeId }}
                      className="press-soft inline-flex items-center gap-1.5 rounded-xl bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground shadow-xs hover:bg-primary/90"
                    >
                      Eps Berikutnya
                      <SkipForward className="size-4" />
                    </Link>
                  ) : (
                    <button
                      disabled
                      className="inline-flex items-center gap-1.5 rounded-xl border border-border/40 bg-muted/40 px-3 py-1.5 text-xs font-semibold text-muted-foreground/50 cursor-not-allowed"
                    >
                      Eps Berikutnya
                      <SkipForward className="size-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Watch Enhancements: Cinema light, sleep timer, shortcuts */}
              <div className="flex items-center justify-between pt-1 border-t border-border/40 text-xs">
                <span className="text-[11px] font-semibold text-muted-foreground">
                  Fitur Pemutar:
                </span>
                {showEnhancements ? (
                  <Suspense fallback={null}><WatchEnhancements isAmbient={isAmbient} onToggleAmbient={() => setIsAmbient((prev) => !prev)} onSleepExpired={() => setIsSleepTriggered(true)} /></Suspense>
                ) : (
                  <button type="button" onClick={() => setShowEnhancements(true)} className="tap-target rounded-xl border border-border px-3 text-xs font-semibold">Buka fitur pemutar</button>
                )}
              </div>
            </div>

            {/* Server Selector Bar */}
            <WatchServerControls qualityGroups={qualityGroups} selectedQuality={selectedQuality} selectedServerId={selectedServerId} isResolving={isResolving} errorMessage={serverError} onQualityChange={setSelectedQuality} onServerSelect={handleServerSelect} />
          </div>

          {/* Download Links Section */}
          {episodeData.downloads && episodeData.downloads.length > 0 ? (
            <div className="rounded-2xl border border-border/80 bg-card p-4 sm:p-5 space-y-4 shadow-sm">
              <div className="flex items-center gap-2 border-b border-border/60 pb-3">
                <Download className="size-4 text-primary" />
                <h3 className="font-display text-sm font-bold text-foreground">
                  Unduh Episode Ini
                </h3>
                <span className="text-xs text-muted-foreground ml-auto">
                  Berbagai pilihan resolusi & penyedia
                </span>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {episodeData.downloads.map((dl) => (
                  <div
                    key={dl.quality}
                    className="rounded-xl border border-border/70 bg-background/60 p-3 space-y-2.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-foreground bg-primary/15 text-primary px-2 py-0.5 rounded-md">
                        {dl.quality}
                      </span>
                      {dl.size ? (
                        <span className="font-semibold text-muted-foreground">{dl.size}</span>
                      ) : null}
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {dl.urls.map((link) => (
                        <a
                          key={link.title + link.url}
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="press-soft inline-flex items-center gap-1 rounded-lg border border-border/70 bg-card px-2.5 py-1 text-[11px] font-medium text-foreground hover:bg-accent hover:border-primary/50"
                        >
                          <ExternalLink className="size-3 text-primary" />
                          {link.title}
                        </a>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>

        {/* Right Episode List Sidebar */}
        <div className={cn(isTheater ? "lg:col-span-12" : "lg:col-span-4 xl:col-span-3")}>
          <WatchEpisodeSidebar episodes={sortedEpisodes} activeEpisodeId={episodeId} animeId={resolvedAnimeId} />
        </div>
      </div>
    </div>
  );
}
