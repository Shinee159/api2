import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CatalogLayout } from "@/components/anime/CatalogLayout";
import { Pagination } from "@/components/anime/Pagination";
import { ongoingQuery } from "@/lib/queries";
export const Route=createFileRoute("/ongoing")({ validateSearch:(s:Record<string,unknown>)=>({page:Number(s.page??1)||1}), component:Page });
function Page(){ const {page}=Route.useSearch(); const navigate=useNavigate(); const q=useQuery(ongoingQuery(page)); return <CatalogLayout title="Anime Sedang Tayang" description="Episode terbaru dari anime yang masih berjalan." items={q.data?.items??[]} isPending={q.isPending} error={q.error} onRetry={()=>q.refetch()} pagination={q.data?<Pagination page={page} hasNext={q.data.hasNext} onChange={next=>navigate({to:"/ongoing",search:{page:next}})}/>:null}/>; }
