import { useRef } from "react";
import { Link } from "@tanstack/react-router";
import type { AnimeSummary } from "@/lib/anime-types";
import { AnimeCard } from "./AnimeCard";
import { RowSkeleton } from "./StateViews";
import { ArrowRight, ChevronLeft, ChevronRight, type LucideIcon } from "lucide-react";

export function Shelf({
  title,
  icon: IconProp,
  items,
  isLoading,
  viewAllTo,
  viewAllSearch,
}: {
  title: string;
  icon?: LucideIcon;
  items: AnimeSummary[];
  isLoading?: boolean;
  viewAllTo?: string;
  viewAllSearch?: Record<string, unknown>;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  if (!isLoading && items.length === 0) return null;

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const offset = direction === "left" ? -480 : 480;
      scrollRef.current.scrollBy({ left: offset, behavior: "smooth" });
    }
  };

  const renderIcon = () => {
    if (!IconProp) return null;
    const IconComp = IconProp as React.ElementType;
    return <IconComp className="h-4 w-4 text-primary" />;
  };

  return (
    <section className="relative z-10 space-y-4 my-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {IconProp ? (
            <span className="tap-target flex items-center justify-center rounded-xl bg-primary/10 text-primary border border-primary/20 shadow-xs shrink-0">
              {renderIcon()}
            </span>
          ) : null}
          <h2 className="font-display text-lg font-bold tracking-tight text-foreground sm:text-xl">
            {title}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          {viewAllTo ? (
            <Link
              to={viewAllTo as never}
              search={viewAllSearch as never}
              className="group inline-flex items-center gap-1 text-xs font-semibold text-primary transition-colors hover:text-primary/80 sm:text-sm"
            >
              <span>Lihat semua</span>
              <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
            </Link>
          ) : null}
          <div className="hidden items-center gap-1 md:flex">
            <button
              type="button"
              onClick={() => scroll("left")}
              aria-label="Gulir ke kiri"
              className="tap-target flex items-center justify-center rounded-lg border border-border/80 bg-secondary/50 text-foreground transition hover:bg-secondary active:scale-95"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => scroll("right")}
              aria-label="Gulir ke kanan"
              className="tap-target flex items-center justify-center rounded-lg border border-border/80 bg-secondary/50 text-foreground transition hover:bg-secondary active:scale-95"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {isLoading ? (
        <RowSkeleton />
      ) : (
        <div
          ref={scrollRef}
          className="edge-fade no-scrollbar -mx-4 flex snap-x snap-mandatory gap-3.5 overflow-x-auto scroll-smooth px-4 pb-4 pt-1 items-stretch"
        >
          {items.map((anime) => (
            <div key={anime.id} className="w-36 shrink-0 snap-start sm:w-44 flex flex-col">
              <AnimeCard anime={anime} />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
