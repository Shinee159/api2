import { Link } from "@tanstack/react-router";
import type { AnimeSummary } from "@/lib/anime-types";
import { CalendarDays } from "lucide-react";

export function HomeSidebar({ items }: { items: AnimeSummary[] }) {
  return <aside className="hidden xl:block">
    <section className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-4 flex items-center justify-between"><div className="flex items-center gap-2"><CalendarDays className="size-5 text-primary"/><h2 className="font-bold">Jadwal Rilis</h2></div><Link to="/jadwal" className="text-xs font-semibold text-primary">Lihat semua →</Link></div>
      <div className="grid grid-cols-2 gap-1 2xl:grid-cols-3">
        {items.slice(0,6).map((anime,index)=><Link key={anime.id} to="/anime/$animeId" params={{animeId:anime.id}} className="grid grid-cols-[2.75rem_1fr_auto] items-center gap-3 rounded-xl p-2 transition hover:bg-muted/60">
          <div className="aspect-[2/3] overflow-hidden rounded-md bg-muted">{anime.poster?<img src={anime.poster} alt="" className="size-full object-cover"/>:null}</div>
          <div className="min-w-0"><p className="truncate text-xs font-semibold">{anime.title}</p><p className="mt-1 text-[10px] text-muted-foreground">{anime.episodeCount?`Episode ${anime.episodeCount}`:"Episode terbaru"}</p></div>
          <div className="text-right"><span className="inline-block size-2 rounded-full bg-primary"/><p className="mt-1 text-[10px] text-muted-foreground">{anime.releaseDay||`Hari ini`}</p></div>
        </Link>)}
      </div>
    </section>
  </aside>;
}
