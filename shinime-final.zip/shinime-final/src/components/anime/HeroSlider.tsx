import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import useEmblaCarousel from "embla-carousel-react";
import type { AnimeSummary } from "@/lib/anime-types";
import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight, Info, Play, Sparkles } from "lucide-react";

export function HeroSlider({items}:{items:AnimeSummary[]}){
 const [emblaRef,emblaApi]=useEmblaCarousel({loop:true,duration:25}); const [selected,setSelected]=useState(0); const [hover,setHover]=useState(false); const timer=useRef<ReturnType<typeof setInterval>|null>(null);
 useEffect(()=>{if(!emblaApi)return;const fn=()=>setSelected(emblaApi.selectedScrollSnap());emblaApi.on("select",fn);fn();return()=>{emblaApi.off("select",fn)}},[emblaApi]);
 useEffect(()=>{if(!emblaApi||items.length<2||hover||matchMedia("(prefers-reduced-motion: reduce)").matches)return;timer.current=setInterval(()=>emblaApi.scrollNext(),6000);return()=>{if(timer.current)clearInterval(timer.current)}},[emblaApi,items.length,hover]);
 if(!items.length)return null;
 return <section onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)} className="relative overflow-hidden rounded-2xl border border-border bg-card shadow-2xl">
  <div ref={emblaRef} className="overflow-hidden"><div className="flex">{items.map(anime=><article key={anime.id} className="relative min-w-0 shrink-0 basis-full overflow-hidden">
   <div className="absolute inset-0">{(anime.cover||anime.poster)?<img src={anime.cover||anime.poster||""} alt="" className="size-full object-cover"/>:null}<div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(7,8,12,.98)_0%,rgba(7,8,12,.87)_36%,rgba(7,8,12,.28)_72%,rgba(7,8,12,.55)_100%)]"/><div className="absolute inset-0 bg-gradient-to-t from-[#07080c] via-transparent to-black/20"/></div>
   <div className="relative z-10 flex min-h-[25rem] items-end p-6 sm:min-h-[28rem] sm:p-10 lg:min-h-[31rem] lg:p-12">
    <div className="max-w-2xl pb-5"><p className="mb-4 inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-[.16em] text-primary"><Sparkles className="size-4"/> Anime of the season</p><h1 className="font-display text-3xl font-extrabold leading-tight sm:text-5xl lg:text-6xl">{anime.title}</h1><p className="mt-4 line-clamp-3 max-w-xl text-sm leading-7 text-white/70 sm:text-base">{anime.synopsis||`Streaming ${anime.title} subtitle Indonesia dengan kualitas pilihan dan multi-server.`}</p><div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-xs text-white/65">{anime.year?<span>{anime.year}</span>:null}{anime.episodeCount?<span>{anime.episodeCount} Episode</span>:null}{anime.genres?.slice(0,3).map(g=><span key={g}>{g}</span>)}</div><div className="mt-6 flex flex-wrap gap-3"><Link to="/anime/$animeId" params={{animeId:anime.id}} className="inline-flex h-11 items-center gap-2 rounded-xl bg-primary px-5 text-sm font-bold text-white shadow-lg shadow-primary/30"><Play className="size-4 fill-current"/>Tonton Sekarang</Link><Link to="/anime/$animeId" params={{animeId:anime.id}} className="inline-flex h-11 items-center gap-2 rounded-xl border border-white/20 bg-black/25 px-5 text-sm font-semibold text-white backdrop-blur"><Info className="size-4"/>Lihat Detail</Link></div></div>
    {anime.poster?<img src={anime.poster} alt="" className="ml-auto hidden h-64 w-44 rounded-xl border border-white/20 object-cover shadow-2xl lg:block"/>:null}
   </div>
  </article>)}</div></div>
  <div className="absolute inset-x-6 bottom-5 z-20 flex items-center justify-between sm:inset-x-10"><span className="text-[10px] font-mono text-white/60">{String(selected+1).padStart(2,"0")} / {String(items.length).padStart(2,"0")}</span><div className="flex gap-2">{items.map((a,i)=><button key={a.id} onClick={()=>emblaApi?.scrollTo(i)} aria-label={`Slide ${i+1}`} className={cn("h-2 rounded-full transition-all",i===selected?"w-8 bg-primary":"w-2 bg-white/25")}/>)}</div><div className="flex gap-2"><button onClick={()=>emblaApi?.scrollPrev()} aria-label="Sebelumnya" className="grid size-9 place-items-center rounded-full border border-white/15 bg-black/30 text-white"><ChevronLeft className="size-4"/></button><button onClick={()=>emblaApi?.scrollNext()} aria-label="Berikutnya" className="grid size-9 place-items-center rounded-full border border-white/15 bg-black/30 text-white"><ChevronRight className="size-4"/></button></div></div>
 </section>
}
