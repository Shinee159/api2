import type { ReactNode } from "react";
import type { AnimeSummary } from "@/lib/anime-types";
import { AnimeGrid } from "./AnimeGrid";
import { EmptyState, ErrorState, GridSkeleton } from "./StateViews";

export function CatalogLayout({ title, description, items, isPending, error, onRetry, toolbar, pagination }: {
  title: string; description?: string; items: AnimeSummary[]; isPending: boolean; error: unknown;
  onRetry(): void; toolbar?: ReactNode; pagination?: ReactNode;
}) {
  return <main className="page-shell min-w-0 space-y-6 py-6 sm:py-8">
    <header className="flex min-w-0 flex-col gap-4 border-b border-border pb-5 md:flex-row md:items-end md:justify-between">
      <div className="min-w-0"><h1 className="break-words text-2xl font-black tracking-tight sm:text-3xl">{title}</h1>{description ? <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{description}</p> : null}</div>
      {toolbar ? <div className="flex min-w-0 flex-wrap items-center gap-2">{toolbar}</div> : null}
    </header>
    {isPending ? <div aria-label="Memuat katalog"><GridSkeleton /></div> : error ? <ErrorState error={error} onRetry={onRetry} /> : items.length === 0 ? <EmptyState message="Tidak ada anime yang ditemukan." /> : <AnimeGrid items={items} />}
    {!isPending && !error && items.length > 0 ? pagination : null}
  </main>;
}
