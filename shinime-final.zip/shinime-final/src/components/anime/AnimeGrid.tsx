import type { AnimeSummary } from "@/lib/anime-types";
import { AnimeCard } from "./AnimeCard";
import { EmptyState } from "./StateViews";
import { Inbox } from "lucide-react";

export function AnimeGrid({ items }: { items: AnimeSummary[] }) {
  if (items.length === 0) return <EmptyState icon={Inbox} message="Tidak ada anime untuk ditampilkan di sini." />;
  return <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">{items.map((anime) => <AnimeCard key={anime.id} anime={anime} />)}</div>;
}
