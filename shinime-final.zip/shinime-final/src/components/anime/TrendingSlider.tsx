import { Link } from "@tanstack/react-router";
import type { AnimeSummary } from "@/lib/anime-types";
import { Flame } from "lucide-react";

export function TrendingSlider({ items }: { items: AnimeSummary[] }) {
  if (!items.length) return null;
  return <section className="space-y-3" aria-labelledby="trending-title">
    <div className="flex items-center justify-between"><div className="flex items-center gap-2"><Flame className="size-5 text-primary"/><h2 id="trending-title" className="text-lg font-bold tracking-tight sm:text-xl">Sedang Tren</h2></div><Link to="/ongoing" search={{page:1}} className="text-xs font-semibold text-primary">Lihat semua →</Link></div>
    <div className="no-scrollbar -mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-2">
      {items.slice(0,10).map((anime,index)=><Link key={anime.id} to="/anime/$animeId" params={{animeId:anime.id}} className="group w-[8.3rem] shrink-0 snap-start sm:w-[9.5rem]">
        <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-border bg-muted shadow-md transition group-hover:-translate-y-1 group-hover:border-primary/50">{anime.poster?<img src={anime.poster} alt={anime.title} loading="lazy" className="size-full object-cover"/>:null}<span className="absolute left-2 top-2 rounded-lg bg-primary px-2 py-1 text-xs font-black text-white shadow-lg">#{index+1}</span><span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 text-[9px] font-bold text-white">{anime.type||"TV"}</span></div>
        <h3 className="mt-2 line-clamp-2 text-xs font-bold leading-5 group-hover:text-primary sm:text-sm">{anime.title}</h3><p className="text-[10px] text-muted-foreground">{anime.year||anime.episodeCount?`${anime.episodeCount||anime.year}${anime.episodeCount?" Eps":""}`:"Sub Indo"}</p>
      </Link>)}
    </div>
  </section>;
}
