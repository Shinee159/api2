import { render, screen } from "@testing-library/react"; import userEvent from "@testing-library/user-event"; import { describe,it,expect,vi } from "vitest";
vi.mock("@tanstack/react-router",()=>({Link:({children,params,search}:any)=><a href={`/watch/${params.episodeId}?a=${search.a}`}>{children}</a>}));
vi.mock("../EpisodeDownloadButton",()=>({EpisodeDownloadButton:()=>null}));
import { EpisodeBrowser } from "../EpisodeBrowser";
describe("EpisodeBrowser",()=>{it("filters by episode number or title and preserves anime context",async()=>{const u=userEvent.setup();render(<EpisodeBrowser animeId="anime-a" episodes={[{id:"ep-1",number:1,title:"Awal"},{id:"ep-12",number:12,title:"Final"}]}/>);await u.type(screen.getByRole("searchbox",{name:/cari episode/i}),"12");expect(screen.getByText("12")).toBeVisible();expect(screen.queryByText("1")).toBeNull();expect(screen.getByRole("link")).toHaveAttribute("href",expect.stringContaining("anime-a"));})})
