import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { CatalogLayout } from "../CatalogLayout";
vi.mock("../AnimeGrid", () => ({ AnimeGrid: ({ items }: any) => <div>{items.length} anime</div> }));
const base = { title:"Katalog", items:[], isPending:false, error:null, onRetry:vi.fn() };
describe("CatalogLayout", () => {
 it("renders loading, error, empty, and populated states exclusively", () => { const { rerender }=render(<CatalogLayout {...base} isPending />); expect(screen.getByLabelText("Memuat katalog")).toBeVisible(); rerender(<CatalogLayout {...base} error={new Error("Offline")} />); expect(screen.getByRole("button",{name:/coba lagi/i})).toBeVisible(); rerender(<CatalogLayout {...base} />); expect(screen.getByText(/tidak ada anime/i)).toBeVisible(); });
 it("keeps toolbar in header",()=>{ render(<CatalogLayout {...base} toolbar={<button>Filter</button>} />); expect(screen.getByRole("button",{name:"Filter"})).toBeVisible(); });
});
