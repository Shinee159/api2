import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { EmptyState } from "../StateViews";
describe("StateViews",()=>{it("renders an empty state without Font Awesome classes",()=>{const {container}=render(<EmptyState message="Belum ada anime"/>);expect(screen.getByText("Belum ada anime")).toBeVisible();expect(container.querySelector('[class*="fa-"]')).toBeNull();});});
