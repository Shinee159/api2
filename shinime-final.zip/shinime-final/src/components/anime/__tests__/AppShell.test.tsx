import { render, screen } from "@testing-library/react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { beforeAll, describe, expect, it, vi } from "vitest";

vi.mock("@tanstack/react-router", () => ({
  Link: ({ children, to, className }: { children: React.ReactNode; to: string; className?: string }) =>
    <a href={to} className={className}>{children}</a>,
  useNavigate: () => vi.fn(),
  useRouterState: () => ({ location: { pathname: "/" } }),
}));
vi.mock("../ThemeToggle", () => ({ ThemeToggle: () => <button>Ganti tema</button> }));
vi.mock("../SpotlightSearchModal", () => ({ SpotlightSearchModal: () => null }));
vi.mock("../SearchFilterPanel", () => ({ SearchFilterPanel: () => null }));
vi.mock("../AnimeGachaModal", () => ({ AnimeGachaModal: () => null }));
vi.mock("@/lib/watchlist", () => ({ readWatchlist: () => [] }));
vi.mock("@/lib/queries", () => ({ searchQuery: () => ({ queryKey: ["search"], queryFn: async () => ({ data: [] }), enabled: false }) }));

beforeAll(() => {
  window.matchMedia ??= vi.fn().mockReturnValue({ matches: true });
});

function renderShell(ui: React.ReactNode) {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(<QueryClientProvider client={client}>{ui}</QueryClientProvider>);
}

describe("application shell", () => {
  it("exposes the core destinations in desktop and mobile navigation", async () => {
    const { SiteHeader } = await import("../SiteHeader");
    const { BottomNav } = await import("../BottomNav");
    renderShell(<><SiteHeader /><BottomNav /></>);
    expect(screen.getAllByText("Beranda").length).toBeGreaterThan(0);
    expect(screen.getAllByText("Jadwal").length).toBeGreaterThan(0);
    expect(screen.getByRole("button", { name: /cari anime/i })).toBeVisible();
  });

  it("uses accessible labels on icon-only actions", async () => {
    const { SiteHeader } = await import("../SiteHeader");
    renderShell(<SiteHeader />);
    expect(screen.getByRole("button", { name: /ganti tema/i })).toBeVisible();
  });
});
