import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { ContinueWatching } from "../ContinueWatching";
vi.mock("@tanstack/react-router",()=>({Link:({children,...props}:any)=><a href={`/watch/${props.params?.episodeId??"history"}`}>{children}</a>}));
const item={episodeId:"ep-1",animeId:"a",animeTitle:"One Piece",episodeTitle:"Episode 1",poster:"",watchedAt:1};
describe("ContinueWatching",()=>{it("hides empty and links populated history",()=>{const {rerender}=render(<ContinueWatching items={[]}/>);expect(screen.queryByRole("heading",{name:/lanjutkan menonton/i})).toBeNull();rerender(<ContinueWatching items={[item]}/>);expect(screen.getByRole("link",{name:/lanjutkan one piece/i})).toHaveAttribute("href",expect.stringContaining("ep-1"));});});
