import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
vi.mock("@tanstack/react-router",()=>({Link:({children}:any)=><a href="#">{children}</a>}));
vi.mock("../WatchlistButton",()=>({WatchlistButton:()=>null}));
vi.mock("../AnimeQuickPreviewModal",()=>({AnimeQuickPreviewModal:()=>null}));
vi.mock("@/lib/history",()=>({readHistory:()=>[]}));
import { AnimeCard } from "../AnimeCard";
const anime:any={id:"a",title:"Judul Anime Yang Sangat Panjang Sampai Melebihi Lebar Kartu",poster:"/bad.jpg"};
describe("AnimeCard",()=>{it("keeps a stable labeled fallback after image failure",()=>{render(<AnimeCard anime={anime}/>);fireEvent.error(screen.getByRole("img",{name:anime.title}));expect(screen.getByTestId("poster-fallback")).toHaveClass("aspect-[2/3]");expect(screen.getAllByText(anime.title).length).toBeGreaterThan(0);});});
