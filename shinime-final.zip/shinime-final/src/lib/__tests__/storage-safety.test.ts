import { beforeEach, describe, expect, it, vi } from "vitest";
import { addToWatchlist, readWatchlist } from "../watchlist";
import { readHistory, saveHistory } from "../history";

describe("local storage safety", () => {
  beforeEach(() => vi.restoreAllMocks());

  it("does not throw when localStorage writes fail", () => {
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => { throw new DOMException("denied"); });
    expect(() => saveHistory({ episodeId: "ep", animeId: "a", animeTitle: "Anime", episodeTitle: "Episode 1", poster: "", watchedAt: Date.now() })).not.toThrow();
    expect(() => addToWatchlist("a", "Anime", "")).not.toThrow();
  });

  it("returns empty arrays for malformed stored JSON", () => {
    vi.spyOn(Storage.prototype, "getItem").mockReturnValue("{");
    expect(readHistory()).toEqual([]);
    expect(readWatchlist()).toEqual([]);
  });
});
