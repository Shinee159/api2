export interface StreamSelectionResult { url: string | null; selectedServerId: string | null; error: string | null; }
export async function resolveStreamSelection({ serverId, previousUrl, resolve }: { serverId: string; previousUrl: string | null; resolve: (serverId: string) => Promise<{ url?: string | null }>; }): Promise<StreamSelectionResult> {
  try { const result = await resolve(serverId); if (!result.url) throw new Error("missing url"); return { url: result.url, selectedServerId: serverId, error: null }; }
  catch { return { url: previousUrl, selectedServerId: null, error: "Server gagal dimuat. Pilih server lain atau coba kembali." }; }
}
