export const siteConfig = {
  name: "Shinime",
  siteUrl: "https://shinime.vercel.app/",
  description: "Streaming anime subtitle Indonesia.",
  ogImage: "/og-image.jpg",
};
